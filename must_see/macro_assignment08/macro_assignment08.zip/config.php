<?php
    $path = '/home/yx2021'.'/databases';
    $db = new SQLite3($path.'/discussion.db');
?>
