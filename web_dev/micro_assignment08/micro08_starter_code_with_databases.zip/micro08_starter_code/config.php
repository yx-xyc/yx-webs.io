<?php

  // define your file path here
  $path = '/your/file/path/here';

 ?>
